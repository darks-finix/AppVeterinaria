import{b as a,c as b}from"./chunk-PD2PSGYJ.js";import"./chunk-JHI3MBHO.js";export{a as GESTURE_CONTROLLER,b as createGesture};
